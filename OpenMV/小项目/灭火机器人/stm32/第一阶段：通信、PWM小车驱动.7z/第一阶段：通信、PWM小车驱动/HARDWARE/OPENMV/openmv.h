#ifndef _OPENMV_H
#define _OPENMV_H
#include "sys.h"

void Data_Processing(u8 *data_buf,u8 num) ;
void Receive_Prepare(u8 data);

extern u8 X;
extern u8 Y;

#endif
