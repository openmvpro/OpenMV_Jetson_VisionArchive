# OpenMV_PCB
 OpenMV PCB Project  
 OPENMV本是国外的开源项目，MIT协议允许任何人使用修改复制售卖。
 TB：https://item.taobao.com/item.htm?spm=a1z10.1-c-s.w4004-17480225679.8.bc5821d6jzZt2j&id=618072724609
 开源让所有人都能自己做! 
# 正面插MT9V034全局摄像头
# 背面可直插OV7725 OV2640 OV5640
# DIY交流群：554150925
